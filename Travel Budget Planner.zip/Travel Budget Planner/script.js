/* =========================================================
   TRIPWISE - TRAVEL BUDGET PLANNER
   JAVASCRIPT
========================================================= */


/* =========================
   GET ELEMENTS
========================= */

const tripForm = document.getElementById("tripForm");

const resetButton =
    document.getElementById("resetButton");


/* =========================
   FORM SUBMIT
========================= */

tripForm.addEventListener("submit", function (event) {

    event.preventDefault();

    calculateBudget();

});


/* =========================
   CALCULATE BUDGET
========================= */

function calculateBudget() {

    /* ---------- TRIP DETAILS ---------- */

    const destination =
        document.getElementById("destination").value.trim();

    const travelers =
        Number(document.getElementById("travelers").value);

    const days =
        Number(document.getElementById("days").value);

    const budget =
        Number(document.getElementById("budget").value);


    /* ---------- EXPENSES ---------- */

    const accommodation =
        getValue("accommodation");

    const food =
        getValue("food");

    const transportation =
        getValue("transportation");

    const activities =
        getValue("activities");

    const other =
        getValue("other");


    /* =========================
       VALIDATION
    ========================= */

    if (destination === "") {

        showAlert("Please enter your destination.");

        return;
    }


    if (travelers <= 0) {

        showAlert("Please enter a valid number of travelers.");

        return;
    }


    if (days <= 0) {

        showAlert("Please enter the number of travel days.");

        return;
    }


    if (budget <= 0) {

        showAlert("Please enter your total travel budget.");

        return;
    }


    /* =========================
       TOTAL CALCULATION
    ========================= */

    const totalCost =
        accommodation +
        food +
        transportation +
        activities +
        other;


    const remaining =
        budget - totalCost;


    const perPerson =
        totalCost / travelers;


    /* =========================
       BUDGET PERCENTAGE
    ========================= */

    let percentage = 0;

    if (budget > 0) {

        percentage =
            (totalCost / budget) * 100;

    }


    const displayPercentage =
        Math.round(percentage);


    /* =========================
       UPDATE SUMMARY
    ========================= */

    document.getElementById(
        "summaryDestination"
    ).textContent = destination;


    document.getElementById(
        "totalCost"
    ).textContent = formatCurrency(totalCost);


    document.getElementById(
        "summaryBudget"
    ).textContent = formatCurrency(budget);


    document.getElementById(
        "perPerson"
    ).textContent = formatCurrency(perPerson);


    /* =========================
       REMAINING BUDGET
    ========================= */

    const remainingElement =
        document.getElementById("remainingBudget");


    if (remaining >= 0) {

        remainingElement.textContent =
            formatCurrency(remaining);

        remainingElement.className =
            "positive";

    } else {

        remainingElement.textContent =
            "-" + formatCurrency(Math.abs(remaining));

        remainingElement.className =
            "positive";

    }


    /* =========================
       PROGRESS BAR
    ========================= */

    const progressFill =
        document.getElementById("progressFill");


    const budgetPercentage =
        document.getElementById("budgetPercentage");


    const safePercentage =
        Math.min(displayPercentage, 100);


    progressFill.style.width =
        safePercentage + "%";


    budgetPercentage.textContent =
        displayPercentage + "%";


    /* =========================
       EXPENSE BREAKDOWN
    ========================= */

    document.getElementById(
        "breakAccommodation"
    ).textContent =
        formatCurrency(accommodation);


    document.getElementById(
        "breakFood"
    ).textContent =
        formatCurrency(food);


    document.getElementById(
        "breakTransportation"
    ).textContent =
        formatCurrency(transportation);


    document.getElementById(
        "breakActivities"
    ).textContent =
        formatCurrency(activities);


    document.getElementById(
        "breakOther"
    ).textContent =
        formatCurrency(other);


    /* =========================
       STATUS
    ========================= */

    updateBudgetStatus(
        remaining,
        percentage
    );


    /* =========================
       SMART TIP
    ========================= */

    generateSavingTip(
        accommodation,
        food,
        transportation,
        activities,
        other,
        totalCost,
        budget
    );


    /* =========================
       SAVE DATA
    ========================= */

    saveTripData({

        destination,
        travelers,
        days,
        budget,

        accommodation,
        food,
        transportation,
        activities,
        other

    });

}


/* =========================
   GET NUMBER VALUE
========================= */

function getValue(id) {

    const value =
        Number(document.getElementById(id).value);

    return value > 0 ? value : 0;

}


/* =========================
   CURRENCY FORMAT
========================= */

function formatCurrency(amount) {

    return "₹" + Number(amount).toLocaleString(
        "en-IN",
        {
            maximumFractionDigits: 0
        }
    );

}


/* =========================
   BUDGET STATUS
========================= */

function updateBudgetStatus(
    remaining,
    percentage
) {

    const status =
        document.getElementById("budgetStatus");


    if (remaining >= 0) {

        status.className =
            "status-box success";


        status.innerHTML = `

            <span>✓</span>

            <div>

                <strong>
                    You're within budget!
                </strong>

                <p>
                    You still have
                    ${formatCurrency(remaining)}
                    available.
                </p>

            </div>

        `;

    } else {

        const extra =
            Math.abs(remaining);


        status.className =
            "status-box danger";


        status.innerHTML = `

            <span>!</span>

            <div>

                <strong>
                    You're over budget
                </strong>

                <p>
                    You need to reduce expenses by
                    ${formatCurrency(extra)}.
                </p>

            </div>

        `;

    }

}


/* =========================
   SMART SAVING TIP
========================= */

function generateSavingTip(
    accommodation,
    food,
    transportation,
    activities,
    other,
    totalCost,
    budget
) {

    const tip =
        document.getElementById("savingTip");


    let message = "";


    if (totalCost === 0) {

        message =
            "Add your estimated expenses to receive a smart travel-saving suggestion.";

    }

    else if (totalCost > budget) {

        if (accommodation >= food &&
            accommodation >= transportation &&
            accommodation >= activities &&
            accommodation >= other) {

            message =
                "Accommodation is your largest expense. Consider budget hotels, hostels or shared stays to reduce your total cost.";

        }

        else if (food >= transportation &&
            food >= activities &&
            food >= other) {

            message =
                "Food is taking a large part of your budget. Try local restaurants and avoid frequent premium dining.";

        }

        else if (transportation >= activities &&
            transportation >= other) {

            message =
                "Transportation is a major expense. Compare public transport, shared rides and advance booking options.";

        }

        else {

            message =
                "Your activities and additional expenses are high. Prioritize the experiences that matter most and set a daily spending limit.";

        }

    }

    else if (totalCost <= budget * 0.7) {

        message =
            "Excellent planning! You are using less than 70% of your budget. You have a comfortable financial buffer for your trip.";

    }

    else {

        message =
            "Your budget looks healthy. Keep a small emergency reserve for unexpected travel expenses.";

    }


    tip.innerHTML = `

        <span class="tip-icon">
            💡
        </span>

        <div>

            <strong>
                Smart Travel Tip
            </strong>

            <p>
                ${message}
            </p>

        </div>

    `;

}


/* =========================
   SAVE TRIP
========================= */

function saveTripData(data) {

    localStorage.setItem(
        "tripWiseData",
        JSON.stringify(data)
    );

}


/* =========================
   LOAD SAVED TRIP
========================= */

function loadTripData() {

    const savedData =
        localStorage.getItem("tripWiseData");


    if (!savedData) {

        return;

    }


    try {

        const data =
            JSON.parse(savedData);


        document.getElementById(
            "destination"
        ).value =
            data.destination || "";


        document.getElementById(
            "travelers"
        ).value =
            data.travelers || "";


        document.getElementById(
            "days"
        ).value =
            data.days || "";


        document.getElementById(
            "budget"
        ).value =
            data.budget || "";


        document.getElementById(
            "accommodation"
        ).value =
            data.accommodation || "";


        document.getElementById(
            "food"
        ).value =
            data.food || "";


        document.getElementById(
            "transportation"
        ).value =
            data.transportation || "";


        document.getElementById(
            "activities"
        ).value =
            data.activities || "";


        document.getElementById(
            "other"
        ).value =
            data.other || "";


        calculateBudget();


    } catch (error) {

        console.log(
            "Unable to load saved trip."
        );

    }

}


/* =========================
   RESET
========================= */

resetButton.addEventListener(
    "click",
    function () {

        tripForm.reset();


        localStorage.removeItem(
            "tripWiseData"
        );


        /* Reset summary */

        document.getElementById(
            "summaryDestination"
        ).textContent =
            "Your destination";


        document.getElementById(
            "totalCost"
        ).textContent =
            "₹0";


        document.getElementById(
            "summaryBudget"
        ).textContent =
            "₹0";


        document.getElementById(
            "remainingBudget"
        ).textContent =
            "₹0";


        document.getElementById(
            "perPerson"
        ).textContent =
            "₹0";


        document.getElementById(
            "budgetPercentage"
        ).textContent =
            "0%";


        document.getElementById(
            "progressFill"
        ).style.width =
            "0%";


        /* Reset expenses */

        const expenses = [

            "breakAccommodation",
            "breakFood",
            "breakTransportation",
            "breakActivities",
            "breakOther"

        ];


        expenses.forEach(function (id) {

            document.getElementById(
                id
            ).textContent =
                "₹0";

        });


        /* Reset status */

        const status =
            document.getElementById(
                "budgetStatus"
            );


        status.className =
            "status-box neutral";


        status.innerHTML = `

            <span>●</span>

            <div>

                <strong>
                    Ready to calculate
                </strong>

                <p>
                    Enter your trip details
                </p>

            </div>

        `;


        /* Reset tip */

        document.getElementById(
            "savingTip"
        ).innerHTML = `

            <span class="tip-icon">
                💡
            </span>

            <div>

                <strong>
                    Smart Travel Tip
                </strong>

                <p>
                    Enter your expenses to receive
                    personalized budget suggestions.
                </p>

            </div>

        `;

    }
);


/* =========================
   ALERT
========================= */

function showAlert(message) {

    alert(message);

}


/* =========================
   LOAD SAVED DATA
========================= */

window.addEventListener(
    "DOMContentLoaded",
    function () {

        loadTripData();

    }
);